interface Ekonomican {
	
    double potrosnjaPoKm(); 
}
